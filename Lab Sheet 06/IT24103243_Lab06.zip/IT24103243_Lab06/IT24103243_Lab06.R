setwd("C:/Users/IT24103243/Desktop/IT24103243_Lab06")
##Question 01
#Part 1
#Binomial Distribution
n <- 50
p <- 0.85
#Part 2
#P(X>=47) = 1-P(X<37) = 1-P(X<=36)
1 - pbinom(36,n,p)
##Question 02
#Part 1
#The number of customer calls received per hour
#Part 2
#Poisson distribution
#Part 3
l <- 12
dpois(15,l)
